import os
import streamlit as st
from dotenv import load_dotenv
from google import genai  

load_dotenv()


client = genai.Client(api_key=os.getenv("GOOGLE_API_KEY"))

print("Models available for your key:")
for m in client.models.list():
    if 'generateContent' in m.supported_actions:
        print(f"-> {m.name}")

st.set_page_config(page_title="Gemini Chatbot", page_icon="🤖")
st.header("Sahil Chatbot")


if "chat_history" not in st.session_state:
    st.session_state.chat_history = []

def get_gemini_response(question):
    response = client.models.generate_content(
        model="gemini-2.5-flash", 
        contents=question
    )
    return response.text

user_input = st.text_input("Ask a question:", key="input")
submit = st.button("Ask question")

if submit and user_input:
    answer = get_gemini_response(user_input)
    
    st.session_state.chat_history.append({"user": user_input, "bot": answer})

st.subheader("Chat History")
for chat in st.session_state.chat_history:
    st.write(f"**You:** {chat['user']}")
    st.write(f"**Bot:** {chat['bot']}")
    st.divider()